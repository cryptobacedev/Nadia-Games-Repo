# Nadia Games - setup guide

Nadia Games = a small game engine (`app/`) + question data (`nadia-games-data/`) + one Blogger page.
Your Blogger theme is not rewritten. Delete the Blogger page and the site is exactly as before.

## 1. Put the files online (free, 10 minutes)
Blogger cannot store these files, so host this folder on GitHub Pages:
1. Create a free GitHub account, then a new public repository called `nadia-games`.
2. Upload the contents of this folder (`app/`, `nadia-games-data/`) to the repository.
3. Repository Settings > Pages > Source: "Deploy from a branch" > `main` / root > Save.
4. After a minute your files live at `https://YOUR-USERNAME.github.io/nadia-games/`.
   Open `https://YOUR-USERNAME.github.io/nadia-games/nadia-games-data/manifest.json` in a browser to confirm.

## 2. Create the Blogger page
1. Blogger > Pages > New page. Title: `Nadia Games – Free Online Quiz & Brain Games`.
2. Switch to HTML view and paste `blogger-page-loader.html`.
3. Replace both `YOUR-USERNAME` values with your GitHub username.
4. Options > Permalink: custom, `nadia-games.html` (URL becomes /p/nadia-games.html).
   Options > Search description: `Play free quiz and brain games on Nadia Games: Nigeria trivia, sports, music, movies, riddles, memory games and a daily challenge. No sign-up. Fun for kids and adults.`
5. Publish. Stay in HTML view (Blogger's Compose view can damage code).

No GitHub? Use `blogger-page-inline.html` instead. It carries the whole engine inside the page
(you still need the data folder hosted somewhere, and you set `data-base` to its address).

## 3. Upload the new theme
Upload `nadia_theme_v10_games.xml` (Theme > Edit HTML). It adds a GAMES link in the menu and footer,
keeps the Listen player off the game page, and gives the page more room. Back up first.

## 4. Ads (important)
- AdSense > Sites > nadiagist247.com > Auto ads > Page exclusions: exclude `/p/nadia-games.html`.
  This keeps ads away from buttons and out of the children's area. Review Google's child-directed
  content rules before ever adding ads here.
- The engine itself contains no ad code.

## 5. Add or edit questions
Each file in `nadia-games-data/questions/` looks like this:
```
{"file":"nigeria","v":1,"questions":[
 {"id":"ng001","s":"history","d":1,"q":"Question text?","o":["A","B","C","D"],"a":1,"e":"Short explanation."}
]}
```
- `s` = topic id (must exist in manifest.json for that category), `d` = difficulty 1 (easy) to 5 (very hard)
- `o` = options, `a` = index of the right option (0 = first). The game shuffles options.
- `t:"tf"` for True/False (options exactly ["True","False"]), `t:"rd"` for riddles.
- Memory-match emoji sets live under `"memory":[[...],[...]]` in `kids.json` and `riddles.json`.
- Keep ids unique. After editing, bump `data-v="1"` to `data-v="2"` on the Blogger page so phones fetch fresh data.
- Add a whole new category by adding it to `manifest.json` and dropping its file into `questions/`.

## 6. How it behaves
- Score: +100 per correct answer, up to +50 speed bonus on timed questions, streak bonuses at 3, 5 and 10 in a row.
- XP = score / 10. Level N needs 25 x (N-1) x (N+2) XP. Streak = at least one game on consecutive Lagos days.
- Daily challenge: category rotates by weekday (set in manifest.json), questions chosen from today's date so everyone gets the same ten.
- Progress, best scores and "My top scores" live in the visitor's browser (localStorage, key `ng_v1`). Nothing is sent anywhere.
- Deep links used by your articles: `#daily`, `#kids`, `#c=sports`, `#c=nigeria`, `#c=entertainment`, `#c=world`, `#c=brain`, `#c=puzzles`.

## 7. Leaderboard later (version 2 design)
Never trust a score sent from the browser. Safe design: the server (for example an Apps Script web app) issues
a signed quiz session with the question ids, the browser sends back only the chosen answers, and the server
recomputes the score and stores it. The local "My top scores" list stays as the offline fallback.
