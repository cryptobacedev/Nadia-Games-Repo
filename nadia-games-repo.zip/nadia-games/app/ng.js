/* Nadia Games engine v1 - isolated: one IIFE, no globals, everything inside #nadia-games-app */
(function () {
  'use strict';
  var root = document.getElementById('nadia-games-app');
  if (!root || root.getAttribute('data-ng-ready')) { return; }
  root.setAttribute('data-ng-ready', '1');

  var BASE = (root.getAttribute('data-base') || '').replace(/\/+$/, '') + '/';
  var VER = root.getAttribute('data-v') || '1';
  var KEY = 'ng_v1';
  var M = null;          /* manifest */
  var CACHE = {};        /* loaded question files */
  var S = null;          /* saved progress */
  var G = null;          /* current game */
  var tickId = null, audioCtx = null, toastTimer = null, nextTimer = null;
  var stage = null, toastEl = null;

  var DIFF = {
    easy: { label: 'Easy', icon: '🌱', desc: 'Relaxed. No timer.', timer: 0, ramp: [1, 1, 1, 2, 1, 2, 2, 1, 2, 2] },
    level: { label: 'Level', icon: '📈', desc: 'Gets harder as you go.', timer: 20, ramp: [1, 2, 2, 3, 3, 3, 4, 4, 5, 5] },
    pro: { label: 'Pro', icon: '🔥', desc: 'Hard questions. Short timer.', timer: 12, ramp: [3, 4, 4, 4, 4, 5, 5, 5, 5, 5] }
  };
  var MODES = {
    quiz: { label: 'Quiz', icon: '❓', desc: '10 questions. Pick the right answer.', count: 10 },
    speed: { label: 'Speed Round', icon: '⚡', desc: 'As many as you can in 60 seconds.', seconds: 60 },
    tf: { label: 'True or False', icon: '✅', desc: '10 quick true or false questions.', count: 10, timer: 8 },
    riddle: { label: 'Riddles', icon: '🧩', desc: '8 riddles to crack.', count: 8 },
    memory: { label: 'Memory Match', icon: '🃏', desc: 'Find all the matching pairs.' }
  };
  var COLORS = { Blue: '#2563eb', Yellow: '#facc15', Green: '#16a34a', Red: '#dc2626', Purple: '#7c3aed', Orange: '#f97316' };
  var LETTERS = ['A', 'B', 'C', 'D'];

  /* ---------- small helpers ---------- */
  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    if (txt !== undefined && txt !== null) { e.textContent = txt; }
    return e;
  }
  function btn(cls, txt, fn) {
    var b = el('button', cls, txt);
    b.type = 'button';
    if (fn) { b.addEventListener('click', fn); }
    return b;
  }
  function add(parent) {
    for (var i = 1; i < arguments.length; i++) { if (arguments[i]) { parent.appendChild(arguments[i]); } }
    return parent;
  }
  function clear(n) { while (n.firstChild) { n.removeChild(n.firstChild); } }
  function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function shuffle(a, r) {
    var b = a.slice(), i, j, t;
    for (i = b.length - 1; i > 0; i--) {
      j = Math.floor((r ? r() : Math.random()) * (i + 1));
      t = b[i]; b[i] = b[j]; b[j] = t;
    }
    return b;
  }
  function seedRng(str) {
    var h = 1779033703 ^ str.length, i;
    for (i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
    var a = h >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  /* Nigeria has no daylight saving: Lagos time is always UTC+1 */
  function lagos(offsetDays) { return new Date(Date.now() + 3600000 + (offsetDays || 0) * 86400000); }
  function today() { return lagos(0).toISOString().slice(0, 10); }
  function yesterday() { return lagos(-1).toISOString().slice(0, 10); }
  function thr(n) { return 25 * (n - 1) * (n + 2); }           /* xp needed to reach level n */
  function levelOf(xp) { var n = 1; while (xp >= thr(n + 1)) { n++; } return n; }
  function catById(id) {
    for (var i = 0; i < M.categories.length; i++) { if (M.categories[i].id === id) { return M.categories[i]; } }
    return null;
  }

  /* ---------- saved progress (this device only) ---------- */
  function loadSave() {
    var d = { xp: 0, best: {}, top: [], streak: { n: 0, last: '' }, daily: { date: '', best: 0, done: 0 }, played: 0, sound: 0, last: {} };
    try {
      var r = localStorage.getItem(KEY);
      if (r) { var p = JSON.parse(r); for (var k in p) { if (p.hasOwnProperty(k)) { d[k] = p[k]; } } }
    } catch (e) { /* private mode: keep going without saving */ }
    return d;
  }
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* ignore */ } }

  /* ---------- sound (optional, tiny synthesised beeps, off by default) ---------- */
  function beep(freqs, dur, type, vol) {
    if (!S || !S.sound) { return; }
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { return; }
      audioCtx = audioCtx || new AC();
      if (audioCtx.state === 'suspended') { audioCtx.resume(); }
      var t = audioCtx.currentTime;
      freqs.forEach(function (f, i) {
        var o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = type || 'sine';
        o.frequency.value = f;
        g.gain.setValueAtTime(vol || 0.05, t + i * dur);
        g.gain.exponentialRampToValueAtTime(0.0001, t + i * dur + dur * 0.95);
        o.connect(g); g.connect(audioCtx.destination);
        o.start(t + i * dur); o.stop(t + i * dur + dur);
      });
    } catch (e) { /* ignore */ }
  }
  var SND = {
    ok: function () { beep([660, 880], 0.09); },
    bad: function () { beep([220], 0.18, 'triangle'); },
    up: function () { beep([523, 659, 784, 1047], 0.1); },
    tap: function () { beep([440], 0.04); }
  };

  function toast(msg) {
    if (!toastEl) { return; }
    toastEl.textContent = msg;
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.hidden = true; }, 2600);
  }

  /* ---------- screens ---------- */
  function stopTimers() {
    if (tickId) { clearInterval(tickId); tickId = null; }
    if (nextTimer) { clearTimeout(nextTimer); nextTimer = null; }
  }
  function mount(node, focusSel) {
    stopTimers();
    clear(stage);
    stage.appendChild(node);
    var f = focusSel ? node.querySelector(focusSel) : node.querySelector('[data-ngf]');
    if (f) { try { f.focus({ preventScroll: true }); } catch (e) { f.focus(); } }
    var r = root.getBoundingClientRect();
    if (r.top < 0 || r.top > 160) {
      try { root.scrollIntoView({ block: 'start' }); } catch (e2) { /* ignore */ }
    }
  }
  function header(title, backFn, backLabel) {
    var top = el('div', 'ng-top');
    if (backFn) {
      var b = btn('ng-iconbtn', '←', backFn);
      b.setAttribute('aria-label', backLabel || 'Back');
      top.appendChild(b);
    }
    var h = el('h2', '', title);
    h.tabIndex = -1;
    h.setAttribute('data-ngf', '1');
    top.appendChild(h);
    return top;
  }

  function showError() {
    stopTimers();
    var w = el('div', 'ng-card ng-err');
    var h = el('h2', '', 'Nadia Games is temporarily unavailable.');
    h.tabIndex = -1; h.setAttribute('data-ngf', '1');
    add(w, h, el('div', 'ng-muted', 'Please try again.'));
    var row = el('div', 'ng-row');
    add(row, btn('ng-btn ng-primary', 'Try again', boot));
    var a = el('a', 'ng-btn ng-ghost', 'Back to NadiaGist247');
    a.href = '/';
    row.appendChild(a);
    w.appendChild(el('div', '', ''));
    w.appendChild(row);
    if (!stage) { return; }
    clear(stage); stage.appendChild(w);
  }

  function dailyCat() {
    var arr = M.daily && M.daily.length ? M.daily : ['nigeria'];
    return catById(arr[lagos(0).getUTCDay() % arr.length]) || M.categories[0];
  }

  function showHub() {
    G = null;
    var w = el('div', 'ng-hub');
    var lv = levelOf(S.xp), cur = thr(lv), nxt = thr(lv + 1);
    var me = el('div', 'ng-me');
    add(me, el('div', 'ng-lv', 'LEVEL ' + lv + ' · ' + fmt(S.xp) + ' XP'));
    var xw = el('div', 'ng-xpwrap');
    var bar = el('div', 'ng-xpbar');
    var fill = el('b');
    fill.style.width = Math.max(3, Math.round((S.xp - cur) / (nxt - cur) * 100)) + '%';
    bar.appendChild(fill);
    add(xw, bar, el('div', 'ng-xpnote', fmt(nxt - S.xp) + ' XP to Level ' + (lv + 1)));
    me.appendChild(xw);
    var st = S.streak || { n: 0, last: '' };
    var stTxt;
    if (st.n > 0 && (st.last === today())) { stTxt = '🔥 ' + st.n + ' day streak'; }
    else if (st.n > 0 && st.last === yesterday()) { stTxt = '🔥 ' + st.n + ' day streak. Play today to keep it going.'; }
    else { stTxt = '🔥 Start your streak today'; }
    me.appendChild(el('div', 'ng-streak', stTxt));
    w.appendChild(me);

    /* daily challenge */
    var dc = dailyCat();
    var dcard = el('div', 'ng-card ng-hero');
    add(dcard, el('div', 'ng-kicker', '🔥 TODAY\'S CHALLENGE'));
    add(dcard, el('div', 'ng-big', 'Can you score 8/10?'));
    var played = S.daily && S.daily.date === today();
    add(dcard, el('div', 'ng-sub', dc.icon + ' ' + dc.label + ' · ' + (M.dailyCount || 10) + ' questions' + (played ? ' · Today\'s best: ' + fmt(S.daily.best) : '')));
    var dbtn = btn('ng-btn ng-white ng-block', played ? 'PLAY AGAIN' : 'PLAY NOW', function () { startDaily(); });
    dbtn.setAttribute('data-ngf', '1');
    dcard.appendChild(dbtn);
    w.appendChild(dcard);

    /* categories */
    var h = el('h3', 'ng-sec', 'Pick a game');
    w.appendChild(h);
    var grid = el('div', 'ng-grid');
    M.categories.forEach(function (c) {
      var b = btn('ng-cat', '', function () { SND.tap(); if (c.kids) { showKids(); } else { showSetup(c.id); } });
      add(b, el('b', 'ng-ic', c.icon), el('b', 'ng-t', c.label), el('b', 'ng-d', c.desc));
      grid.appendChild(b);
    });
    w.appendChild(grid);

    /* personal top scores (kept on this device) */
    if (S.top && S.top.length) {
      w.appendChild(el('h3', 'ng-sec', '🏆 My top scores'));
      var card = el('div', 'ng-card');
      S.top.slice(0, 3).forEach(function (t) {
        var row = el('div', 'ng-stat');
        add(row, el('b', '', fmt(t.s)), el('b', 'ng-muted', t.c + ' · ' + t.m));
        card.appendChild(row);
      });
      w.appendChild(card);
    }
    w.appendChild(el('div', 'ng-foot', 'Free to play. No sign-up. Your progress is saved on this device.'));
    mount(w);
  }

  /* ---------- kids ---------- */
  function showKids() {
    var c = catById('kids');
    if (!c) { showHub(); return; }
    var w = el('div', 'ng-kids');
    w.appendChild(header('NADIA KIDS 🌈', showHub, 'Back to games'));
    w.appendChild(el('div', 'ng-muted', 'Tap a picture to play!'));
    var grid = el('div', 'ng-kidgrid');
    c.subs.forEach(function (s) {
      var b = btn('ng-cat', '', function () { SND.tap(); startGame({ cat: c, mode: 'quiz', diff: 'easy', sub: s.id, count: 8, kids: true }); });
      add(b, el('b', 'ng-ic', s.icon), el('b', 'ng-t', s.label));
      grid.appendChild(b);
    });
    var mix = btn('ng-cat', '', function () { startGame({ cat: c, mode: 'quiz', diff: 'easy', sub: '', count: 8, kids: true }); });
    add(mix, el('b', 'ng-ic', '🌟'), el('b', 'ng-t', 'Mix it up'));
    grid.appendChild(mix);
    var mem = btn('ng-cat', '', function () { startMemory({ cat: c, diff: 'easy', kids: true }); });
    add(mem, el('b', 'ng-ic', '🃏'), el('b', 'ng-t', 'Memory'));
    grid.appendChild(mem);
    w.appendChild(grid);
    w.appendChild(el('div', 'ng-foot', 'No ads and no sign-up in Nadia Kids.'));
    mount(w);
  }

  /* ---------- game setup ---------- */
  function poolFor(cat, mode, sub) {
    var out = [], ids = cat.subs.map(function (s) { return s.id; });
    cat.files.forEach(function (f) {
      var d = CACHE[f];
      if (!d) { return; }
      d.questions.forEach(function (q) {
        if (ids.indexOf(q.s) === -1) { return; }
        if (sub && q.s !== sub) { return; }
        var t = q.t || '';
        if (mode === 'tf' && t !== 'tf') { return; }
        if (mode === 'riddle' && t !== 'rd') { return; }
        if ((mode === 'quiz' || mode === 'speed') && t) { return; }
        out.push(q);
      });
    });
    return out;
  }
  function loadFiles(names) {
    return Promise.all(names.map(function (n) {
      if (CACHE[n]) { return CACHE[n]; }
      return getJSON('questions/' + n + '.json').then(function (j) { CACHE[n] = j; return j; });
    }));
  }
  function getJSON(path) {
    return new Promise(function (resolve, reject) {
      var done = false;
      var t = setTimeout(function () { if (!done) { done = true; reject(new Error('timeout')); } }, 10000);
      fetch(BASE + path + '?v=' + encodeURIComponent(VER)).then(function (r) {
        if (!r.ok) { throw new Error('http ' + r.status); }
        return r.json();
      }).then(function (j) {
        if (!done) { done = true; clearTimeout(t); resolve(j); }
      }).catch(function (e) {
        if (!done) { done = true; clearTimeout(t); reject(e); }
      });
    });
  }

  function showSetup(catId) {
    var cat = catById(catId);
    if (!cat) { showHub(); return; }
    var last = (S.last && S.last[catId]) || {};
    var sel = {
      mode: (cat.modes.indexOf(last.mode) !== -1) ? last.mode : cat.modes[0],
      diff: last.diff || 'easy',
      sub: ''
    };
    var w = el('div', 'ng-setup');
    w.appendChild(header(cat.icon + ' ' + cat.label, showHub, 'Back to games'));
    var status = el('div', 'ng-muted', 'Loading questions…');
    var startBtn = btn('ng-btn ng-primary ng-block', 'START', null);
    startBtn.disabled = true;
    var chipsBox = el('div', 'ng-chips');
    var modeBox = el('div', 'ng-modes');
    var segBox = el('div', 'ng-seg');
    var ready = false;

    function refresh() {
      /* topic chips */
      var showSubs = cat.subs.length > 1 && sel.mode !== 'memory';
      chipsBox.hidden = !showSubs;
      clear(chipsBox);
      if (showSubs) {
        var avail = {};
        cat.subs.forEach(function (s) { avail[s.id] = ready ? poolFor(cat, sel.mode, s.id).length >= 4 : true; });
        if (sel.sub && !avail[sel.sub]) { sel.sub = ''; }
        var all = btn('ng-chip', 'All topics', function () { sel.sub = ''; refresh(); });
        all.setAttribute('aria-pressed', sel.sub === '' ? 'true' : 'false');
        chipsBox.appendChild(all);
        cat.subs.forEach(function (s) {
          var c = btn('ng-chip', s.icon + ' ' + s.label, function () { sel.sub = s.id; refresh(); });
          c.setAttribute('aria-pressed', sel.sub === s.id ? 'true' : 'false');
          if (!avail[s.id]) { c.disabled = true; }
          chipsBox.appendChild(c);
        });
      }
      /* modes */
      clear(modeBox);
      cat.modes.forEach(function (m) {
        var mm = MODES[m];
        var b = btn('ng-mode', '', function () { sel.mode = m; if (m === 'memory') { sel.sub = ''; } refresh(); });
        b.setAttribute('aria-pressed', sel.mode === m ? 'true' : 'false');
        var tx = el('div', 'ng-mt');
        add(tx, el('b', '', mm.label), el('i', '', mm.desc));
        add(b, el('b', 'ng-ic', mm.icon), tx);
        modeBox.appendChild(b);
      });
      /* difficulty */
      clear(segBox);
      ['easy', 'level', 'pro'].forEach(function (d) {
        var dd = DIFF[d];
        var c = btn('ng-chip', dd.icon + ' ' + dd.label, function () { sel.diff = d; refresh(); });
        c.setAttribute('aria-pressed', sel.diff === d ? 'true' : 'false');
        c.appendChild(el('i', '', dd.desc));
        segBox.appendChild(c);
      });
      /* start state */
      if (!ready) { startBtn.disabled = true; return; }
      var n = sel.mode === 'memory' ? 99 : poolFor(cat, sel.mode, sel.sub).length;
      startBtn.disabled = n < 4;
      status.textContent = n < 4 ? 'Not enough questions for this mix yet. Try another topic or mode.' : (sel.mode === 'memory' ? 'Ready when you are.' : n + ' questions ready.');
    }
    startBtn.addEventListener('click', function () {
      S.last = S.last || {};
      S.last[catId] = { mode: sel.mode, diff: sel.diff };
      persist();
      SND.tap();
      if (sel.mode === 'memory') { startMemory({ cat: cat, diff: sel.diff }); }
      else { startGame({ cat: cat, mode: sel.mode, diff: sel.diff, sub: sel.sub }); }
    });

    add(w, el('div', 'ng-sec', 'Topic'), chipsBox, el('div', 'ng-sec', 'Game'), modeBox, el('div', 'ng-sec', 'Difficulty'), segBox, startBtn, status);
    refresh();
    mount(w);
    loadFiles(cat.files).then(function () { ready = true; refresh(); }).catch(showError);
  }

  /* ---------- question selection ---------- */
  function pickQuestions(pool, targets, rng) {
    var used = {}, out = [];
    targets.forEach(function (t) {
      var cand = pool.filter(function (q) { return !used[q.id] && q.d === t; });
      if (!cand.length) {
        var best = null, bd = 99;
        pool.forEach(function (q) {
          if (used[q.id]) { return; }
          var dd = Math.abs(q.d - t);
          if (dd < bd) { bd = dd; best = [q]; } else if (dd === bd) { best.push(q); }
        });
        cand = best || [];
      }
      if (cand.length) {
        var q = cand[Math.floor(rng() * cand.length)];
        used[q.id] = 1; out.push(q);
      }
    });
    return out;
  }
  function rampFor(n, ramp) {
    var out = [], i;
    for (i = 0; i < n; i++) { out.push(ramp[Math.min(i, ramp.length - 1)]); }
    return out;
  }
  function prepOptions(q) {
    var opts = q.o.map(function (t, i) { return { t: t, c: i === q.a }; });
    return q.t === 'tf' ? opts : shuffle(opts);
  }

  function startDaily() {
    var cat = dailyCat();
    loadFiles(cat.files).then(function () {
      var pool = poolFor(cat, 'quiz', '');
      var rng = seedRng('nadia-' + today() + '-' + cat.id);
      var n = M.dailyCount || 10;
      var qs = pickQuestions(pool, rampFor(n, [1, 1, 2, 2, 2, 3, 3, 3, 4, 4]), rng);
      if (qs.length < 5) { showError(); return; }
      begin({ cat: cat, mode: 'quiz', diff: 'daily', sub: '', daily: true, qs: qs, timer: 0 });
    }).catch(showError);
  }

  function startGame(o) {
    loadFiles(o.cat.files).then(function () {
      var pool = poolFor(o.cat, o.mode, o.sub || '');
      var dcfg = DIFF[o.diff] || DIFF.easy;
      var qs, timer = dcfg.timer, mcfg = MODES[o.mode];
      if (o.kids) { timer = 0; }
      if (o.mode === 'tf') { timer = o.diff === 'easy' ? 0 : (mcfg.timer || 8); }
      if (o.mode === 'speed') {
        var lo = o.diff === 'easy' ? 1 : (o.diff === 'level' ? 1 : 3), hi = o.diff === 'easy' ? 2 : (o.diff === 'level' ? 4 : 5);
        var fit = pool.filter(function (q) { return q.d >= lo && q.d <= hi; });
        if (fit.length < 8) { fit = pool; }
        qs = shuffle(fit);
        timer = 0;
      } else {
        var n = Math.min(o.count || mcfg.count || 10, pool.length);
        qs = pickQuestions(pool, rampFor(n, dcfg.ramp), Math.random);
      }
      if (qs.length < 4) { showError(); return; }
      begin({ cat: o.cat, mode: o.mode, diff: o.diff, sub: o.sub || '', kids: !!o.kids, qs: qs, timer: timer, count: o.count });
    }).catch(showError);
  }

  function begin(o) {
    G = {
      cat: o.cat, mode: o.mode, diff: o.diff, sub: o.sub, daily: !!o.daily, kids: !!o.kids || !!o.cat.kids,
      qs: o.qs, i: 0, score: 0, correct: 0, streak: 0, maxStreak: 0, locked: false,
      limit: (o.timer || 0) * 1000, remain: 0, last: 0, speed: o.mode === 'speed', count: o.count,
      globalLeft: o.mode === 'speed' ? (MODES.speed.seconds || 60) * 1000 : 0, answered: 0, replay: o
    };
    renderQuestion();
  }

  /* ---------- playing ---------- */
  function renderQuestion() {
    var q = G.qs[G.i];
    G.cur = q; G.opts = prepOptions(q); G.locked = false;
    var w = el('div', 'ng-play' + (G.kids ? ' ng-kids' : '') + (q.t === 'tf' ? ' ng-tf' : ''));
    var bar = el('div', 'ng-bar');
    var left = el('b', '', G.speed ? '⚡ Speed Round' : 'Question ' + (G.i + 1) + ' of ' + G.qs.length);
    var right = el('b', '', 'Score ' + fmt(G.score));
    right.id = 'ng-score';
    add(bar, left, right);
    w.appendChild(bar);

    var timed = G.speed || G.limit > 0;
    if (timed) {
      var tm = el('div', 'ng-timer'); tm.id = 'ng-timer';
      tm.setAttribute('role', 'progressbar'); tm.setAttribute('aria-label', 'Time left');
      tm.appendChild(el('b'));
      w.appendChild(tm);
      if (G.speed) { /* global clock continues across questions */ }
      else { G.remain = G.limit; }
    }
    var card = el('div', 'ng-qcard');
    var sub = null, cs = G.cat.subs;
    for (var s = 0; s < cs.length; s++) { if (cs[s].id === q.s) { sub = cs[s]; } }
    if (sub && !G.kids) { card.appendChild(el('div', 'ng-tag', sub.label)); }
    var qq = el('div', 'ng-q', q.q);
    qq.setAttribute('role', 'heading'); qq.setAttribute('aria-level', '2');
    qq.tabIndex = -1; qq.setAttribute('data-ngf', '1');
    card.appendChild(qq);
    w.appendChild(card);

    var box = el('div', 'ng-opts'); box.setAttribute('role', 'group'); box.setAttribute('aria-label', 'Answers');
    G.opts.forEach(function (o, idx) {
      var b = btn('ng-opt', '', function () { answer(idx); });
      var label = el('b', 'ng-ot', o.t);
      b.appendChild(el('b', 'ng-l', LETTERS[idx]));
      b.appendChild(label);
      if (q.s === 'colours' && COLORS[o.t]) { var sw = el('b', 'ng-sw'); sw.style.background = COLORS[o.t]; b.appendChild(sw); }
      box.appendChild(b);
    });
    w.appendChild(box);
    var fb = el('div', 'ng-fbwrap'); fb.id = 'ng-fb'; fb.setAttribute('aria-live', 'polite');
    w.appendChild(fb);
    mount(w);
    G.last = Date.now();
    if (timed) { tickId = setInterval(tick, 100); tick(); }
  }

  function setTimerBar(frac) {
    var t = document.getElementById('ng-timer');
    if (!t) { return; }
    var f = Math.max(0, Math.min(1, frac));
    t.firstChild.style.transform = 'scaleX(' + f + ')';
    if (f < 0.25) { t.className = 'ng-timer ng-low'; } else { t.className = 'ng-timer'; }
  }
  function tick() {
    if (!G) { return; }
    var now = Date.now(), dt = Math.min(now - G.last, 250);
    G.last = now;
    if (document.hidden) { return; }
    if (G.speed) {
      G.globalLeft -= dt;
      setTimerBar(G.globalLeft / ((MODES.speed.seconds || 60) * 1000));
      if (G.globalLeft <= 0) { finish(); }
      return;
    }
    if (G.locked) { return; }
    G.remain -= dt;
    setTimerBar(G.remain / G.limit);
    if (G.remain <= 0) { answer(-1); }
  }

  function answer(idx) {
    if (!G || G.locked || G.finished || !G.cur) { return; }
    G.locked = true;
    var q = G.cur, correctIdx = 0, i;
    for (i = 0; i < G.opts.length; i++) { if (G.opts[i].c) { correctIdx = i; } }
    var ok = idx === correctIdx;
    var pts = 0, sb = 0, stBonus = 0;
    G.answered++;
    if (ok) {
      G.correct++; G.streak++;
      if (G.streak > G.maxStreak) { G.maxStreak = G.streak; }
      pts = 100;
      if (!G.speed && G.limit > 0) { sb = Math.max(0, Math.round(50 * G.remain / G.limit)); }
      stBonus = G.streak === 3 ? 50 : (G.streak === 5 ? 100 : (G.streak === 10 ? 200 : 0));
      G.score += pts + sb + stBonus;
      SND.ok();
    } else { G.streak = 0; SND.bad(); }
    var opts = stage.querySelectorAll('.ng-opt');
    for (i = 0; i < opts.length; i++) {
      opts[i].disabled = true;
      if (i === correctIdx) { opts[i].className += ' ng-right'; opts[i].appendChild(el('b', 'ng-mark', '✓')); }
      else if (i === idx) { opts[i].className += ' ng-wrong'; opts[i].appendChild(el('b', 'ng-mark', '✗')); }
    }
    var sc = document.getElementById('ng-score');
    if (sc) { sc.textContent = 'Score ' + fmt(G.score); }
    var fbw = document.getElementById('ng-fb');
    var correctText = G.opts[correctIdx].t;

    if (G.speed) {
      nextTimer = setTimeout(function () { nextQuestion(); }, ok ? 350 : 700);
      if (fbw) { fbw.appendChild(el('div', 'ng-muted', ok ? '✅ +' + (pts + stBonus) : '❌ ' + correctText)); }
      return;
    }
    var fb = el('div', 'ng-fb ' + (ok ? 'ng-fb-ok' : 'ng-fb-bad'));
    var head;
    if (ok) {
      head = '✅ Correct! +' + pts;
      if (sb) { head += ' +' + sb + ' speed bonus'; }
      if (stBonus) { head += ' 🔥 ' + G.streak + ' in a row! +' + stBonus; }
    } else if (idx === -1) { head = '⏰ Time\'s up! The answer is: ' + correctText; }
    else { head = '❌ Not quite. The answer is: ' + correctText; }
    fb.appendChild(el('b', '', head));
    if (q.e) { fb.appendChild(el('div', 'ng-ex', q.e)); }
    fbw.appendChild(fb);
    var row = el('div', 'ng-row');
    if (!G.kids) {
      var ask = btn('ng-btn ng-ghost', '🤖 Ask Nadia AI', function () {
        askAI('A quiz asked me: "' + q.q + '" The answer is "' + correctText + '". Can you explain why in simple words?');
      });
      row.appendChild(ask);
    }
    var last = G.i + 1 >= G.qs.length;
    var nb = btn('ng-btn ng-primary', last ? 'SEE RESULTS' : 'NEXT →', function () { nextQuestion(); });
    row.appendChild(nb);
    fbw.appendChild(row);
    try { nb.focus({ preventScroll: true }); } catch (e) { nb.focus(); }
    try { nb.scrollIntoView({ block: 'nearest' }); } catch (e2) { /* ignore */ }
  }

  function nextQuestion() {
    if (!G) { return; }
    if (nextTimer) { clearTimeout(nextTimer); nextTimer = null; }
    if (G.speed && G.globalLeft <= 0) { finish(); return; }
    if (G.i + 1 >= G.qs.length) { finish(); return; }
    G.i++;
    renderQuestion();
  }

  function askAI(text) {
    var inp = document.getElementById('n-input');
    if (inp) {
      try {
        inp.value = text;
        inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }));
        return;
      } catch (e) { /* fall through */ }
    }
    window.location.href = (M.site && M.site.chat) || '/p/gist-with-nadia.html';
  }

  /* ---------- memory match ---------- */
  function startMemory(o) {
    loadFiles(o.cat.files).then(function (arr) {
      var sets = [];
      arr.forEach(function (d) { if (d && d.memory) { sets = sets.concat(d.memory); } });
      if (!sets.length) { showError(); return; }
      var pairsN = o.diff === 'easy' ? 6 : 8;
      var set = sets[Math.floor(Math.random() * sets.length)];
      var faces = shuffle(set).slice(0, pairsN);
      var cards = shuffle(faces.concat(faces));
      G = { cat: o.cat, mode: 'memory', diff: o.diff, kids: !!o.kids || !!o.cat.kids, daily: false, score: 0, correct: 0, total: pairsN, moves: 0, open: [], locked: false, replay: o, qs: [], answered: 0, streak: 0, maxStreak: 0 };
      var w = el('div', 'ng-play' + (G.kids ? ' ng-kids' : ''));
      var bar = el('div', 'ng-bar');
      var mv = el('b', '', 'Moves 0'); mv.id = 'ng-moves';
      var pr = el('b', '', 'Pairs 0/' + pairsN); pr.id = 'ng-pairs';
      add(bar, mv, pr);
      w.appendChild(bar);
      var h = el('div', 'ng-q ng-center', 'Find the matching pairs');
      h.tabIndex = -1; h.setAttribute('data-ngf', '1');
      h.setAttribute('role', 'heading'); h.setAttribute('aria-level', '2');
      w.appendChild(h);
      var grid = el('div', 'ng-mem');
      grid.style.marginTop = '12px';
      cards.forEach(function (face, idx) {
        var c = btn('ng-mc', '?', null);
        c.setAttribute('aria-label', 'Card ' + (idx + 1) + ', face down');
        c.addEventListener('click', function () { flip(c, face, idx); });
        grid.appendChild(c);
      });
      w.appendChild(grid);
      mount(w);
    }).catch(showError);
  }
  function flip(c, face, idx) {
    if (!G || G.mode !== 'memory' || G.locked || c.classList.contains('ng-open') || c.classList.contains('ng-done')) { return; }
    c.classList.add('ng-open'); c.textContent = face; c.setAttribute('aria-label', 'Card ' + (idx + 1) + ', ' + face);
    c._face = face;
    G.open.push(c);
    SND.tap();
    if (G.open.length < 2) { return; }
    G.moves++;
    document.getElementById('ng-moves').textContent = 'Moves ' + G.moves;
    var a = G.open[0], b = G.open[1];
    G.open = [];
    if (a._face === b._face) {
      a.className = 'ng-mc ng-done'; b.className = 'ng-mc ng-done';
      a.disabled = true; b.disabled = true;
      G.correct++;
      SND.ok();
      document.getElementById('ng-pairs').textContent = 'Pairs ' + G.correct + '/' + G.total;
      if (G.correct >= G.total) {
        var extra = Math.max(0, G.moves - G.total);
        G.score = Math.max(100, G.total * 120 - extra * (G.diff === 'pro' ? 25 : 15));
        nextTimer = setTimeout(finish, 500);
      }
    } else {
      G.locked = true;
      SND.bad();
      nextTimer = setTimeout(function () {
        [a, b].forEach(function (x) { x.className = 'ng-mc'; x.textContent = '?'; x.setAttribute('aria-label', 'Card, face down'); });
        G.locked = false;
      }, 750);
    }
  }

  /* ---------- results ---------- */
  function finish() {
    if (!G) { return; }
    stopTimers();
    var g = G;
    if (g.finished) { return; }
    g.finished = true; g.cur = null;
    var total = g.mode === 'memory' ? g.total : (g.speed ? g.answered : g.qs.length);
    var key = g.daily ? 'daily' : (g.cat.id + '|' + g.mode + '|' + g.diff);
    var prevBest = S.best[key] || 0;
    var isBest = g.score > prevBest && g.score > 0;
    if (isBest) { S.best[key] = g.score; }
    var lvBefore = levelOf(S.xp);
    var gain = Math.max(5, Math.round(g.score / 10));
    var dailyFirst = false;
    if (g.daily) {
      dailyFirst = S.daily.date !== today();
      if (dailyFirst) { gain += 50; S.daily = { date: today(), best: g.score, done: 1 }; }
      else { S.daily.best = Math.max(S.daily.best, g.score); S.daily.done = (S.daily.done || 0) + 1; }
    }
    S.xp += gain; S.played = (S.played || 0) + 1;
    var lvAfter = levelOf(S.xp);
    /* streak: at least one finished game per Lagos day */
    var st = S.streak || { n: 0, last: '' };
    if (st.last !== today()) { st.n = (st.last === yesterday()) ? st.n + 1 : 1; st.last = today(); }
    S.streak = st;
    S.top = (S.top || []).concat([{ s: g.score, c: g.cat.label, m: g.daily ? 'Daily' : MODES[g.mode].label, d: today() }]).sort(function (a, b) { return b.s - a.s; }).slice(0, 5);
    persist();
    g.result = { total: total, gain: gain, lvBefore: lvBefore, lvAfter: lvAfter, isBest: isBest, prevBest: prevBest, dailyFirst: dailyFirst };
    renderResult();
    if (lvAfter > lvBefore) { SND.up(); } else if (g.correct > 0) { SND.ok(); }
  }

  function renderResult() {
    var g = G, r = g.result;
    var w = el('div', 'ng-result' + (g.kids ? ' ng-kids' : ''));
    var pct = r.total ? g.correct / r.total : 0;
    var msg;
    if (g.kids) { msg = pct >= 0.75 ? '⭐⭐⭐ Super star!' : (pct >= 0.4 ? '⭐⭐ Well done!' : '⭐ Good try!'); }
    else if (pct >= 0.9) { msg = '🏆 Brilliant!'; }
    else if (pct >= 0.7) { msg = '🔥 Great job!'; }
    else if (pct >= 0.5) { msg = '👍 Good effort!'; }
    else { msg = '💪 Keep going!'; }
    var h = el('h2', 'ng-center', 'YOUR SCORE');
    h.tabIndex = -1; h.setAttribute('data-ngf', '1');
    w.appendChild(h);
    w.appendChild(el('div', 'ng-score', fmt(g.score)));
    var c = el('div', 'ng-center');
    c.appendChild(el('div', 'ng-msg', msg));
    if (r.isBest && r.prevBest > 0) { c.appendChild(el('div', 'ng-pb', '🎉 NEW PERSONAL BEST!')); }
    w.appendChild(c);
    var card = el('div', 'ng-card');
    function stat(a, b) { var row = el('div', 'ng-stat'); add(row, el('b', 'ng-muted', a), el('b', '', b)); card.appendChild(row); }
    if (g.mode === 'memory') { stat('Pairs found', g.correct + ' / ' + g.total); stat('Moves', String(g.moves)); }
    else { stat('Correct answers', g.correct + ' / ' + r.total); if (g.maxStreak >= 2) { stat('Best streak', '🔥 ' + g.maxStreak); } }
    if (!r.isBest || r.prevBest === 0) { stat('Your best', fmt(Math.max(r.prevBest, g.score))); }
    stat('XP earned', '+' + r.gain + (r.dailyFirst ? ' (includes +50 daily bonus)' : ''));
    var lv = levelOf(S.xp);
    stat('Level ' + lv, fmt(thr(lv + 1) - S.xp) + ' XP to Level ' + (lv + 1));
    if (g.daily) { stat('Today\'s best', fmt(S.daily.best)); }
    stat('Streak', '🔥 ' + S.streak.n + ' day' + (S.streak.n === 1 ? '' : 's'));
    w.appendChild(card);
    if (r.lvAfter > r.lvBefore) { var up = el('div', 'ng-msg', '🎉 LEVEL UP! You are now Level ' + r.lvAfter); w.appendChild(up); }

    var row = el('div', 'ng-row');
    row.appendChild(btn('ng-btn ng-primary', 'PLAY AGAIN', playAgain));
    if (!g.daily && !g.kids) { row.appendChild(btn('ng-btn ng-ghost', 'DAILY CHALLENGE', startDaily)); }
    var next = g.diff === 'easy' ? 'level' : (g.diff === 'level' ? 'pro' : '');
    if (next && !g.daily && !g.kids && g.mode !== 'memory') {
      row.appendChild(btn('ng-btn ng-ghost', 'TRY ' + DIFF[next].label.toUpperCase(), function () {
        startGame({ cat: g.cat, mode: g.mode, diff: next, sub: g.sub, count: g.count });
      }));
    }
    row.appendChild(btn('ng-btn ng-ghost', g.kids ? 'BACK TO KIDS' : 'BACK TO GAMES', g.kids ? showKids : showHub));
    w.appendChild(row);
    if (!g.kids) {
      var sh = btn('ng-btn ng-ghost ng-block', '📣 SHARE RESULT', shareResult);
      sh.style.marginTop = '10px';
      w.appendChild(sh);
    }
    mount(w);
  }

  function playAgain() {
    var g = G;
    if (g.mode === 'memory') { startMemory({ cat: g.cat, diff: g.diff, kids: g.kids }); }
    else if (g.daily) { begin({ cat: g.cat, mode: 'quiz', diff: 'daily', sub: '', daily: true, qs: g.qs.slice(0).map(function (q) { return q; }), timer: 0 }); }
    else { startGame({ cat: g.cat, mode: g.mode, diff: g.diff, sub: g.sub, kids: g.kids, count: g.count }); }
  }

  function shareResult() {
    var url = (M.site && M.site.share) || (location.href.split('#')[0]);
    var text = '🏆 I scored ' + fmt(G.score) + ' points on Nadia Games!\nCan you beat me?';
    if (navigator.share) {
      navigator.share({ title: 'Nadia Games', text: text, url: url }).catch(function () { /* cancelled */ });
      return;
    }
    var full = text + ' ' + url;
    function wa() { window.open('https://wa.me/?text=' + encodeURIComponent(full), '_blank', 'noopener'); }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(full).then(function () { toast('Copied! Paste it anywhere to challenge a friend.'); }, wa);
    } else { wa(); }
  }

  /* ---------- keyboard (only inside the game) ---------- */
  root.addEventListener('keydown', function (e) {
    if (!G || !G.cur || G.mode === 'memory') { return; }
    var k = (e.key || '').toLowerCase(), n = -1;
    if (k >= '1' && k <= '4') { n = parseInt(k, 10) - 1; }
    else if (k === 'a' || k === 'b' || k === 'c' || k === 'd') { n = k.charCodeAt(0) - 97; }
    if (n >= 0 && n < G.opts.length && !G.locked && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); answer(n); }
  });

  /* ---------- chrome + boot ---------- */
  function buildShell() {
    clear(root);
    var head = el('div', 'ng-head');
    var brand = el('div', 'ng-brand', '🎮 NADIA GAMES');
    var snd = btn('ng-iconbtn', S.sound ? '🔊' : '🔇', null);
    snd.setAttribute('aria-label', S.sound ? 'Sound on. Tap to mute' : 'Sound off. Tap to turn on');
    snd.setAttribute('aria-pressed', S.sound ? 'true' : 'false');
    snd.addEventListener('click', function () {
      S.sound = S.sound ? 0 : 1; persist();
      snd.textContent = S.sound ? '🔊' : '🔇';
      snd.setAttribute('aria-pressed', S.sound ? 'true' : 'false');
      snd.setAttribute('aria-label', S.sound ? 'Sound on. Tap to mute' : 'Sound off. Tap to turn on');
      if (S.sound) { SND.tap(); }
    });
    add(head, brand, snd);
    stage = el('div', 'ng-stage');
    stage.appendChild(el('div', 'ng-boot', 'Loading Nadia Games…'));
    toastEl = el('div', 'ng-toast'); toastEl.hidden = true; toastEl.setAttribute('role', 'status');
    add(root, head, stage, toastEl);
  }

  function route() {
    var h = (location.hash || '').replace(/^#/, '');
    if (h === 'daily') { startDaily(); return; }
    if (h === 'kids') { showKids(); return; }
    var m = h.match(/^c=([a-z]+)/);
    if (m && catById(m[1])) { var c = catById(m[1]); if (c.kids) { showKids(); } else { showSetup(m[1]); } return; }
    showHub();
  }

  function boot() {
    try {
      S = S || loadSave();
      if (!stage) { buildShell(); } else { clear(stage); stage.appendChild(el('div', 'ng-boot', 'Loading Nadia Games…')); }
      if (/YOUR-|your-/.test(BASE) || !BASE || BASE === '/') { if (window.console) { console.warn('Nadia Games: set data-base on #nadia-games-app'); } showError(); return; }
      getJSON('manifest.json').then(function (j) {
        M = j;
        if (!M.categories || !M.categories.length) { throw new Error('bad manifest'); }
        if (M.difficulty) { for (var k in M.difficulty) { if (M.difficulty.hasOwnProperty(k) && DIFF[k]) { DIFF[k] = M.difficulty[k]; } } }
        if (M.modes) { for (var m in M.modes) { if (M.modes.hasOwnProperty(m) && MODES[m]) { MODES[m] = M.modes[m]; } } }
        route();
      }).catch(function () { showError(); });
    } catch (e) { showError(); }
  }
  document.addEventListener('visibilitychange', function () { if (G) { G.last = Date.now(); } });
  boot();
})();
